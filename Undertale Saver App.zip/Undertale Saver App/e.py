import os
import shutil
import stat
import json
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from send2trash import send2trash
import tkinter.font as tkFont

# === Paths ===
undertale_save = os.path.join(os.getenv("LOCALAPPDATA"), "UNDERTALE")
downloads = os.path.join(os.path.expanduser("~"), "Downloads")
save_root = os.path.join(downloads, "Undertale Saver")
lock_file = os.path.join(save_root, "locked.json")
undertale_exe = r"C:\Program Files (x86)\Steam\steamapps\common\Undertale\UNDERTALE.exe"  # Update if needed

# === Ensure Save Folder Exists ===
if not os.path.exists(save_root):
    os.makedirs(save_root)

# === GUI Setup ===
root = tk.Tk()
root.title("Undertale Saver")
root.geometry("520x480")
colors = {"bg": "black", "fg": "white", "btn": "yellow"}
root.configure(bg=colors["bg"])

# === Font Setup ===
font_family = "Determination Mono"
font_size = 12
try:
    custom_font = tkFont.Font(family=font_family, size=font_size)
except tk.TclError:
    custom_font = tkFont.Font(size=font_size)

# === GUI Variables ===
save_var = tk.StringVar()
rename_var = tk.StringVar()
sort_mode = tk.StringVar(value="Name")

# === Locking Logic ===
def load_locked():
    if os.path.exists(lock_file):
        with open(lock_file, "r") as f:
            return json.load(f)
    return []

def save_locked(locked_list):
    with open(lock_file, "w") as f:
        json.dump(locked_list, f)

def toggle_lock():
    slot = save_var.get()
    locked = load_locked()
    if slot in locked:
        locked.remove(slot)
        messagebox.showinfo("Unlocked", f"'{slot}' is now unlocked.")
    else:
        locked.append(slot)
        messagebox.showinfo("Locked", f"'{slot}' is now locked.")
    save_locked(locked)
    refresh_dropdown()

# === Save Slot Functions ===
def get_save_slots():
    folders = [f for f in os.listdir(save_root) if os.path.isdir(os.path.join(save_root, f))]
    if sort_mode.get() == "Name":
        return sorted(folders)
    elif sort_mode.get() == "Date":
        return sorted(folders, key=lambda f: os.path.getctime(os.path.join(save_root, f)), reverse=True)
    return folders

def refresh_dropdown():
    slots = get_save_slots()
    save_dropdown['values'] = slots
    if slots:
        save_dropdown.current(0)

def get_next_save_slot():
    existing = get_save_slots()
    numbers = [int(f.replace("Save_", "")) for f in existing if f.startswith("Save_") and f.replace("Save_", "").isdigit()]
    next_num = max(numbers, default=0) + 1
    return f"Save_{next_num:02}"

def backup_current():
    slot_name = get_next_save_slot()
    target_path = os.path.join(save_root, slot_name)
    os.makedirs(target_path)
    for file in os.listdir(undertale_save):
        shutil.copy2(os.path.join(undertale_save, file), os.path.join(target_path, file))
    messagebox.showinfo("Backup Done", f"Backed up save to: {slot_name}")
    refresh_dropdown()

def clear_undertale_folder():
    for item in os.listdir(undertale_save):
        path = os.path.join(undertale_save, item)
        try:
            os.chmod(path, stat.S_IWRITE)
            send2trash(path)
        except Exception:
            pass

def restore_save(slot_folder):
    source_path = os.path.join(save_root, slot_folder)
    if not os.path.exists(source_path):
        messagebox.showerror("Error", f"Save slot '{slot_folder}' not found.")
        return
    if not os.path.exists(undertale_save):
        os.makedirs(undertale_save)
    for file in os.listdir(source_path):
        shutil.copy2(os.path.join(source_path, file), os.path.join(undertale_save, file))
    messagebox.showinfo("Restore Complete", f"Restored save from: {slot_folder}")

# === Button Actions ===
def restore_selected():
    folder = save_var.get()
    if folder in load_locked():
        messagebox.showwarning("Locked", f"'{folder}' is locked and cannot be restored.")
        return
    backup_current()
    clear_undertale_folder()
    restore_save(folder)

def rename_selected():
    old_name = save_var.get()
    new_name = rename_var.get().strip()
    if old_name in load_locked():
        messagebox.showwarning("Locked", f"'{old_name}' is locked and cannot be renamed.")
        return
    if not old_name or not new_name:
        messagebox.showerror("Error", "Select a save and enter a new name.")
        return
    os.rename(os.path.join(save_root, old_name), os.path.join(save_root, new_name))
    messagebox.showinfo("Rename Complete", f"Renamed '{old_name}' to '{new_name}'")
    refresh_dropdown()

def create_blank_save():
    name = rename_var.get().strip()
    if not name:
        messagebox.showerror("Error", "Enter a name for the new save.")
        return
    path = os.path.join(save_root, name)
    if os.path.exists(path):
        messagebox.showerror("Error", "A folder with that name already exists.")
        return
    os.makedirs(path)
    for file in os.listdir(undertale_save):
        shutil.copy2(os.path.join(undertale_save, file), os.path.join(path, file))
    clear_undertale_folder()
    restore_save(name)
    messagebox.showinfo("Blank Save Created", f"Created and restored blank save: {name}")
    refresh_dropdown()

def delete_selected():
    slot = save_var.get()
    if slot in load_locked():
        messagebox.showwarning("Locked", f"'{slot}' is locked and cannot be deleted.")
        return
    confirm = simpledialog.askstring("Confirm Delete", f"Type '{slot}' to confirm deletion:")
    if confirm == slot:
        shutil.rmtree(os.path.join(save_root, slot), ignore_errors=True)
        messagebox.showinfo("Deleted", f"'{slot}' has been deleted.")
        refresh_dropdown()
    else:
        messagebox.showinfo("Cancelled", "Deletion cancelled.")

def launch_undertale():
    if os.path.exists(undertale_exe):
        try:
            subprocess.Popen([undertale_exe])
            messagebox.showinfo("Game Launched", "UNDERTALE is starting...")
        except Exception as e:
            messagebox.showwarning("Launch Failed", f"Could not launch UNDERTALE:\n{e}")
    else:
        messagebox.showerror("Game Not Found", "UNDERTALE.exe not found. Check your install path.")

# === Styled Widgets ===
def styled_label(text):
    return tk.Label(root, text=text, fg=colors["fg"], bg=colors["bg"], font=custom_font)

def styled_entry(var):
    return tk.Entry(root, textvariable=var, fg=colors["fg"], bg=colors["bg"], insertbackground=colors["fg"], font=custom_font)

def styled_button(text, command):
    return tk.Button(root, text=text, command=command, fg=colors["btn"], bg=colors["bg"], font=custom_font)

# === GUI Layout ===
styled_label("Select Save Slot:").pack(pady=5)
save_dropdown = ttk.Combobox(root, textvariable=save_var, state="readonly", font=custom_font)
save_dropdown.pack(pady=5)

styled_button("Restore Save", restore_selected).pack(pady=3)
styled_button("Lock/Unlock Save", toggle_lock).pack(pady=3)
styled_button("Delete Save", delete_selected).pack(pady=3)

styled_label("Rename or Create Save:").pack(pady=5)
styled_entry(rename_var).pack(pady=5)

styled_button("Rename Save", rename_selected).pack(pady=3)
styled_button("Create Blank Save", create_blank_save).pack(pady=3)

styled_label("Sort By:").pack()
ttk.Combobox(root, textvariable=sort_mode, values=["Name", "Date"], state="readonly", font=custom_font).pack()

styled_button("Finish & Launch UNDERTALE", launch_undertale).pack(pady=10)

refresh_dropdown()
root.mainloop()